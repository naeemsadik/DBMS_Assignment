
	<footer class="section">
		<div class="center grey-text">&copy; Copyright 2019 Ninja Pizzas</div>
	</footer>
</body>